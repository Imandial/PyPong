$HEADER$
void main (void){
    gl_FragColor = frag_color * texture2D(texture0, tex_coord0);
}
